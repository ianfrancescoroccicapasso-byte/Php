<?php


// Incluye los ficheros de datos y funciones necesarios.
require_once 'datos.php';
require_once 'funciones.php';

// Recogemos el parámetro de la URL mediante $_GET de forma segura
$codigoCompra = $_GET['compra'] ?? null;
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>La Tienda de Música</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 30px;
            color: #111;
        }

        h1 {
            font-size: 28px;
            margin-bottom: 25px;
        }

        table {
            border-collapse: collapse;
            margin-top: 15px;
        }

        th,
        td {
            padding: 6px 35px 6px 0;
            text-align: left;
        }

        /* Alineamos a la derecha la columna de precios si es necesario, o dejamos left según la captura */
        th:last-child,
        td:last-child {
            text-align: right;
        }

        a {
            color: #512da8;
            text-decoration: underline;
        }

        .error {
            color: #d32f2f;
            margin-bottom: 25px;
            text-align: center;
            width: 100%;
            max-width: 500px;
        }
    </style>
</head>

<body>

    <h1>La Tienda de Música</h1>

    <?php

    if ($codigoCompra !== null):
    ?>
        <?php
        // Verificamos si la clave del producto existe dentro del array del catálogo
        if (array_key_exists($codigoCompra, $catalogo)):
            $prod = $catalogo[$codigoCompra];
            $precioSinIVA = $prod['precio'];
            $ivaImporte = calcularIVA($precioSinIVA);
            $total = $precioSinIVA + $ivaImporte;
        ?>



            <p>Ticket de compra &middot; <?php echo $codigoCompra; ?></p>
            <hr style="border: none; border-top: 1px dashed #777; width: 100%; max-width: 450px; text-align: left; margin-left: 0;">

            <table>
                <tr>
                    <td>Producto</td>
                    <td><?php echo $prod['nombre']; ?></td>
                </tr>
                <tr>
                    <td>Marca</td>
                    <td><?php echo $prod['marca']; ?></td>
                </tr>
                <tr>
                    <td>Precio sin IVA</td>
                    <td><?php echo $euros($precioSinIVA); ?></td>
                </tr>
                <tr>
                    <td>IVA (21%)</td>
                    <td><?php echo $euros($ivaImporte); ?></td>
                </tr>
                <tr>
                    <td><strong>TOTAL</strong></td>
                    <td><strong><?php echo $euros($total); ?></strong></td>
                </tr>
            </table>

        <?php else: ?>
            //Mostramos aviso si el código introducido por URL no es válido.
            <p class="error">El código de producto "<?php echo htmlspecialchars($codigoCompra); ?>" no existe en el catálogo.</p>
        <?php endif; ?>

    <?php else: ?>

        <p class="error">No has indicado ningún producto. Elige uno del catálogo:</p>

        <table>
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Producto</th>
                    <th>Marca</th>
                    <th>Precio</th>
                </tr>
            </thead>
            <tbody>
                <?php
                //Recorremos el array asociativo del catálogo para pintar cada fila de la tabla
                foreach ($catalogo as $codigo => $item):
                ?>
                    <tr>
                        <td><a href="index.php?compra=<?php echo $codigo; ?>"><?php echo $codigo; ?></a></td>
                        <td><?php echo $item['nombre']; ?></td>
                        <td><?php echo $item['marca']; ?></td>
                        <td><?php echo $euros($item['precio']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

</body>

</html>