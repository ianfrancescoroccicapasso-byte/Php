<?php
/**
 * DATOS - Tienda de música
 */

const IVA = 0.21;

// Catálogo: código del producto => datos del producto
$catalogo = [
    'G1' => ['nombre' => 'Guitarra acústica',    'marca' => 'Yamaha',  'precio' => 189.00],
    'B1' => ['nombre' => 'Bajo eléctrico',       'marca' => 'Fender',  'precio' => 449.00],
    'T1' => ['nombre' => 'Teclado 61 teclas',    'marca' => 'Casio',   'precio' => 159.90],
    'U1' => ['nombre' => 'Ukelele soprano',      'marca' => 'Ortega',  'precio' => 59.50],
    'D1' => ['nombre' => 'Batería electrónica',  'marca' => 'Roland',  'precio' => 699.00],
    'V1' => ['nombre' => 'Violín 4/4',           'marca' => 'Stentor', 'precio' => 129.00],
    'S1' => ['nombre' => 'Saxofón alto',         'marca' => 'Jupiter', 'precio' => 799.00],
    'C1' => ['nombre' => 'Cajón flamenco',       'marca' => 'Meinl',   'precio' => 89.90],
    'F1' => ['nombre' => 'Flauta travesera',     'marca' => 'Pearl',   'precio' => 349.00],
    'A1' => ['nombre' => 'Armónica diatónica',   'marca' => 'Hohner',  'precio' => 39.95],
];