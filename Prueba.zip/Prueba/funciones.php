<?php
// Función para calcular el importe del IVA
// Calculamos el 21% y retornamos el resultado
function calcularIVA($precio) {
    return $precio * IVA;
}
// Declaración global de la función flecha (arrow function) para formatear los importes con dos decimales y símbolo de euro
global $euros;
$euros = fn($importe) => number_format($importe, 2, ',', '.') . ' €';